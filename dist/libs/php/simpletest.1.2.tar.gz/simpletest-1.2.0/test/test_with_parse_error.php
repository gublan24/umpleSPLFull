<?php
    
    
    class TestCaseWithParseError extends UnitTestCase {
        wibble
    }
    
?>