<?php

class IteratorImplementation implements Iterator
{
    public function current()
    {
    }

    public function next()
    {
    }

    public function key()
    {
    }

    public function valid()
    {
    }

    public function rewind()
    {
    }
}

class IteratorAggregateImplementation implements IteratorAggregate
{
    public function getIterator()
    {
    }
}
