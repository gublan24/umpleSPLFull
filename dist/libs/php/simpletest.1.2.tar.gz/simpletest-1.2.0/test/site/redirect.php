<?php
    header('Location: http://localhost:8080/network_confirm.php?r=rrr');
?><html>
    <head><title>Redirection test</title></head>
    <body>This is a test page for the SimpleTest PHP unit tester</body>
</html>