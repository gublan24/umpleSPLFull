Please see http://pholser.github.com/jopt-simple for more information.
