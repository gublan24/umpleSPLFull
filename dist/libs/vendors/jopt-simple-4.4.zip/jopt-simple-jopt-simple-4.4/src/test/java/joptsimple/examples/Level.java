package joptsimple.examples;

public enum Level {
    WARNING,
    INFO,
    DEBUG
}
